#
# TABLE STRUCTURE FOR: absen
#

DROP TABLE IF EXISTS `absen`;

CREATE TABLE `absen` (
  `id_absen` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(40) NOT NULL,
  `tanggal` date NOT NULL,
  `jam_masuk` time NOT NULL,
  `jam_keluar` time NOT NULL,
  `status` varchar(30) NOT NULL,
  PRIMARY KEY (`id_absen`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `absen` (`id_absen`, `username`, `tanggal`, `jam_masuk`, `jam_keluar`, `status`) VALUES (1, 'norman', '2021-03-11', '12:46:09', '00:00:00', 'masuk');


#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(25) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `image` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `admin` (`id`, `nama`, `username`, `password`, `image`) VALUES (4, 'admin', 'admin123', '$2y$10$0Txe4v9P/m9tGrlG6QiXoeTzsIIKf/4e79k7reWxaeV5Ph85nuvD.', 'default.png');
INSERT INTO `admin` (`id`, `nama`, `username`, `password`, `image`) VALUES (6, 'asfasdf', 'tester', '$2y$10$ItgWexh/JThhVh9MZOXTeOsIj5U4LtSrcpJX.KTCk7TY8AbXUOkpm', 'default.png');
INSERT INTO `admin` (`id`, `nama`, `username`, `password`, `image`) VALUES (7, 'asfasf', 'testinggg', '$2y$10$8fRxc6Tgl9w4LzTuzR0/.eQ7RycjdLDz6b4WY0m./gki4z/C9ZdFG', 'default.png');


#
# TABLE STRUCTURE FOR: jabatan
#

DROP TABLE IF EXISTS `jabatan`;

CREATE TABLE `jabatan` (
  `id_jabatan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_jabatan` varchar(40) NOT NULL,
  PRIMARY KEY (`id_jabatan`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (5, 'asfsafa');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (6, 'bos');
INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (7, 'pembantu');


#
# TABLE STRUCTURE FOR: karyawan
#

DROP TABLE IF EXISTS `karyawan`;

CREATE TABLE `karyawan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(25) NOT NULL,
  `username` varchar(20) NOT NULL,
  `jabatan` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `image` varchar(30) NOT NULL,
  `is_active` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `karyawan` (`id`, `nama`, `username`, `jabatan`, `password`, `image`, `is_active`) VALUES (1, 'Norman Ardian', 'norman', 5, '$2y$10$o7y6y2FWa4ikjw2OxrNwU.7UMWm.6hsg3Hj8odCA4aEQJ71iER88C', 'default.jpg', 1);
INSERT INTO `karyawan` (`id`, `nama`, `username`, `jabatan`, `password`, `image`, `is_active`) VALUES (2, 'anuanu', 'anuanu', 6, '$2y$10$EuzQeGN00dhfkfZAx3GUVuFgmMd4hEuqM2Wemz/wZ3bg.n7vRsbl6', 'default.jpg', 1);
INSERT INTO `karyawan` (`id`, `nama`, `username`, `jabatan`, `password`, `image`, `is_active`) VALUES (3, 'gian', 'giancok', 7, '$2y$10$Q9FAn0PRudCx6HfUg5j6hOCeTKy/lR8w2ui2LLDiB/ssL05/gMCEe', 'default.jpg', 1);
INSERT INTO `karyawan` (`id`, `nama`, `username`, `jabatan`, `password`, `image`, `is_active`) VALUES (4, 'coba', 'cobaaja', 6, '$2y$10$OdzCXpDWZoFOwLnZlQgXFOdOaUKn6u7XlVb1GMmqGL54B8NolLIgK', 'default.jpg', 1);
INSERT INTO `karyawan` (`id`, `nama`, `username`, `jabatan`, `password`, `image`, `is_active`) VALUES (5, 'coba baru lagi', 'nyoba', 7, '$2y$10$kKZs96SxgDSGp4xR1CDO7OKkiI3Gm6IOObVkszIoSDFSLfvw5froO', 'default.jpg', 1);


